@call auto-clean %*
