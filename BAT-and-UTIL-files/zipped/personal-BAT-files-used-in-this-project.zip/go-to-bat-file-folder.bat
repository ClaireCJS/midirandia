@echo off
%BAT\
